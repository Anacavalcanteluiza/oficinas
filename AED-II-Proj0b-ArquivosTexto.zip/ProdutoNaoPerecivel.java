/** Produto que não tem data de validade. */
public class ProdutoNaoPerecivel extends Produto {

    public ProdutoNaoPerecivel(String descricao, double precoCusto, double margemLucro) {
        super(descricao, precoCusto, margemLucro);
    }

    public ProdutoNaoPerecivel(String descricao, double precoCusto) {
        super(descricao, precoCusto);
    }

    /** Para este tipo, o preço é custo mais a margem de lucro. */
    @Override
    public double valorDeVenda() {
        return precoComMargem();
    }

    /** O número 1 identifica produtos não perecíveis no arquivo. */
    @Override
    public String gerarDadosTexto() {
        return String.format(java.util.Locale.ROOT, "1;%s;%.2f;%.2f",
                getDescricao(), getPrecoCusto(), getMargemLucro());
    }
}
