import java.util.Locale;

/**
 * Dados e comportamentos que todos os produtos têm em comum.
 * A classe é abstrata: cada tipo concreto de produto define seu próprio preço.
 */
public abstract class Produto {
    private static final double MARGEM_PADRAO = 0.20;

    private final String descricao;
    private final double precoCusto;
    private final double margemLucro;

    public Produto(String descricao, double precoCusto, double margemLucro) {
        if (descricao == null || descricao.trim().length() < 3) {
            throw new IllegalArgumentException("Descrição deve ter pelo menos 3 caracteres.");
        }
        if (precoCusto < 0.01) {
            throw new IllegalArgumentException("Preço de custo deve ser pelo menos 0,01.");
        }
        if (margemLucro < 0.01) {
            throw new IllegalArgumentException("Margem de lucro deve ser pelo menos 0,01.");
        }
        if (descricao.contains(";")) {
            throw new IllegalArgumentException("A descrição não pode conter ponto e vírgula.");
        }

        this.descricao = descricao.trim();
        this.precoCusto = precoCusto;
        this.margemLucro = margemLucro;
    }

    public Produto(String descricao, double precoCusto) {
        this(descricao, precoCusto, MARGEM_PADRAO);
    }

    public String getDescricao() {
        return descricao;
    }

    public double getPrecoCusto() {
        return precoCusto;
    }

    public double getMargemLucro() {
        return margemLucro;
    }

    /** Calcula o custo acrescido da margem definida para este produto. */
    protected double precoComMargem() {
        return precoCusto * (1 + margemLucro);
    }

    /** Cada tipo de produto fornece sua regra de cálculo do preço de venda. */
    public abstract double valorDeVenda();

    /** Cada classe filha converte seus dados para uma linha do arquivo. */
    public abstract String gerarDadosTexto();

    /**
     * Constrói o tipo certo de produto a partir de uma linha do arquivo.
     * Exemplo: 1;Arroz;10.00;0.20 ou 2;Iogurte;5.00;0.20;29/09/2026
     */
    public static Produto criarDoTexto(String linha) {
        if (linha == null || linha.trim().isEmpty()) {
            throw new IllegalArgumentException("A linha do produto está vazia.");
        }

        String[] partes = linha.split(";", -1);
        try {
            int tipo = Integer.parseInt(partes[0].trim());
            String descricao = partes[1].trim();
            double custo = Double.parseDouble(partes[2].trim().replace(',', '.'));
            double margem = Double.parseDouble(partes[3].trim().replace(',', '.'));

            if (tipo == 1 && partes.length == 4) {
                return new ProdutoNaoPerecivel(descricao, custo, margem);
            }
            if (tipo == 2 && partes.length == 5) {
                java.time.LocalDate validade = java.time.LocalDate.parse(
                        partes[4].trim(), java.time.format.DateTimeFormatter.ofPattern("dd/MM/uuuu"));
                return new ProdutoPerecivel(descricao, custo, margem, validade);
            }
            throw new IllegalArgumentException("Tipo ou quantidade de campos inválida.");
        } catch (IndexOutOfBoundsException | NumberFormatException ex) {
            throw new IllegalArgumentException("A linha não segue o formato esperado.", ex);
        }
    }

    /** Compara produtos pelo nome, sem diferenciar letras maiúsculas e minúsculas. */
    @Override
    public boolean equals(Object outro) {
        if (this == outro) return true;
        if (!(outro instanceof Produto)) return false;
        Produto produto = (Produto) outro;
        return descricao.equalsIgnoreCase(produto.descricao);
    }

    /** Garante que produtos com o mesmo nome tenham o mesmo código de hash. */
    @Override
    public int hashCode() {
        return descricao.toLowerCase(Locale.ROOT).hashCode();
    }

    @Override
    public String toString() {
        return String.format(Locale.forLanguageTag("pt-BR"), "%s: R$ %,.2f",
                descricao, valorDeVenda());
    }
}
