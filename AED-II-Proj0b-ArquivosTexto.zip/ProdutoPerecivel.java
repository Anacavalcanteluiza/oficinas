import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;

/** Produto que possui uma data de validade. */
public class ProdutoPerecivel extends Produto {
    private static final long DIAS_PARA_DESCONTO = 3;
    private static final double DESCONTO = 0.25;
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/uuuu");

    private final LocalDate validade;

    public ProdutoPerecivel(String descricao, double precoCusto,
                            double margemLucro, LocalDate validade) {
        super(descricao, precoCusto, margemLucro);
        validarValidade(validade);
        this.validade = validade;
    }

    public ProdutoPerecivel(String descricao, double precoCusto, LocalDate validade) {
        super(descricao, precoCusto);
        validarValidade(validade);
        this.validade = validade;
    }

    private static void validarValidade(LocalDate validade) {
        if (validade == null) {
            throw new IllegalArgumentException("A data de validade é obrigatória.");
        }
        if (validade.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("O produto não pode estar vencido.");
        }
    }

    public LocalDate getValidade() {
        return validade;
    }

    /** Aplica 25% de desconto quando faltam três dias ou menos para vencer. */
    @Override
    public double valorDeVenda() {
        double precoNormal = precoComMargem();
        long diasRestantes = ChronoUnit.DAYS.between(LocalDate.now(), validade);
        return diasRestantes <= DIAS_PARA_DESCONTO
                ? precoNormal * (1 - DESCONTO)
                : precoNormal;
    }

    /** O número 2 identifica perecíveis; a validade é gravada como dia/mês/ano. */
    @Override
    public String gerarDadosTexto() {
        return String.format(java.util.Locale.ROOT, "2;%s;%.2f;%.2f;%s",
                getDescricao(), getPrecoCusto(), getMargemLucro(), validade.format(FORMATO_DATA));
    }
}
