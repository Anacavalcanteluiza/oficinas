import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/** Programa principal para cadastrar, procurar, listar e salvar produtos. */
public class Comercio {
    private static final int MAX_NOVOS_PRODUTOS = 100;
    private static final Scanner teclado = new Scanner(System.in);

    private static Produto[] produtosCadastrados = new Produto[MAX_NOVOS_PRODUTOS];
    private static int quantidadeProdutos = 0;
    private static String nomeArquivoDados = "dadosProdutos.csv";

    /** Lê produtos salvos e deixa espaço para até 100 novos cadastros. */
    public static Produto[] lerProdutos(String nomeArquivo) {
        try (BufferedReader leitor = Files.newBufferedReader(Path.of(nomeArquivo), StandardCharsets.UTF_8)) {
            String primeiraLinha = leitor.readLine();
            if (primeiraLinha == null) throw new IOException("Arquivo sem quantidade de produtos.");

            int quantidadeNoArquivo = Integer.parseInt(primeiraLinha.trim());
            if (quantidadeNoArquivo < 0) throw new IOException("Quantidade inválida.");

            Produto[] vetor = new Produto[quantidadeNoArquivo + MAX_NOVOS_PRODUTOS];
            for (int i = 0; i < quantidadeNoArquivo; i++) {
                String linha = leitor.readLine();
                if (linha == null) throw new IOException("Faltam produtos no arquivo.");
                vetor[i] = Produto.criarDoTexto(linha);
            }
            quantidadeProdutos = quantidadeNoArquivo;
            return vetor;
        } catch (IOException | RuntimeException erro) {
            // Um arquivo ausente ou inválido não impede a abertura do programa.
            quantidadeProdutos = 0;
            return new Produto[MAX_NOVOS_PRODUTOS];
        }
    }

    /** Mostra todos os produtos, numerando-os para facilitar a leitura. */
    public static void listarTodosOsProdutos() {
        if (quantidadeProdutos == 0) {
            System.out.println("Ainda não há produtos cadastrados.");
            return;
        }
        for (int i = 0; i < quantidadeProdutos; i++) {
            System.out.println((i + 1) + ". " + produtosCadastrados[i]);
        }
    }

    /** Procura a descrição informada, ignorando diferenças entre maiúsculas e minúsculas. */
    public static void localizarProdutos() {
        System.out.print("Digite o nome do produto: ");
        String nome = teclado.nextLine().trim();
        boolean encontrou = false;

        // Compara o nome digitado com a descrição de cada produto cadastrado.
        for (int i = 0; i < quantidadeProdutos; i++) {
            if (produtosCadastrados[i].getDescricao().equalsIgnoreCase(nome)) {
                System.out.println(produtosCadastrados[i]);
                encontrou = true;
            }
        }
        if (!encontrou) System.out.println("Produto não encontrado.");
    }

    /** Pergunta os dados necessários e cria um produto do tipo escolhido. */
    public static void cadastrarProduto() {
        try {
            System.out.println("Tipo de produto:");
            System.out.println("1. Não perecível");
            System.out.println("2. Perecível");
            System.out.print("Escolha: ");
            int tipo = Integer.parseInt(teclado.nextLine().trim());

            System.out.print("Descrição: ");
            String descricao = teclado.nextLine().trim();
            double custo = lerDecimal("Preço de custo: ");
            double margem = lerDecimal("Margem de lucro (ex.: 0,20 para 20%): ");

            Produto novo;
            if (tipo == 1) {
                novo = new ProdutoNaoPerecivel(descricao, custo, margem);
            } else if (tipo == 2) {
                System.out.print("Validade (dd/mm/aaaa): ");
                LocalDate validade = LocalDate.parse(teclado.nextLine().trim(),
                        DateTimeFormatter.ofPattern("dd/MM/uuuu"));
                novo = new ProdutoPerecivel(descricao, custo, margem, validade);
            } else {
                System.out.println("Tipo inválido. Cadastro cancelado.");
                return;
            }

            garantirEspaco();
            produtosCadastrados[quantidadeProdutos] = novo;
            quantidadeProdutos++;
            System.out.println("Produto cadastrado: " + novo);
        } catch (IllegalArgumentException erro) {
            System.out.println("Não foi possível cadastrar: " + erro.getMessage());
        }
    }

    /** Converte vírgula ou ponto decimal para o formato numérico do Java. */
    private static double lerDecimal(String mensagem) {
        System.out.print(mensagem);
        return Double.parseDouble(teclado.nextLine().trim().replace(',', '.'));
    }

    /** Aumenta o vetor quando os cadastros ultrapassarem o espaço inicial. */
    private static void garantirEspaco() {
        if (quantidadeProdutos == produtosCadastrados.length) {
            Produto[] maior = new Produto[produtosCadastrados.length + MAX_NOVOS_PRODUTOS];
            System.arraycopy(produtosCadastrados, 0, maior, 0, quantidadeProdutos);
            produtosCadastrados = maior;
        }
    }

    /** Grava a quantidade e depois uma linha para cada produto. */
    public static void salvarProdutos(String nomeArquivo) {
        try (BufferedWriter escritor = Files.newBufferedWriter(Path.of(nomeArquivo), StandardCharsets.UTF_8)) {
            escritor.write(Integer.toString(quantidadeProdutos));
            escritor.newLine();
            for (int i = 0; i < quantidadeProdutos; i++) {
                escritor.write(produtosCadastrados[i].gerarDadosTexto());
                escritor.newLine();
            }
            System.out.println("Dados salvos em " + nomeArquivo + ".");
        } catch (IOException erro) {
            System.out.println("Erro ao salvar os produtos: " + erro.getMessage());
        }
    }

    private static int menu() {
        System.out.println("\n===== COMÉRCIO =====");
        System.out.println("1. Listar produtos");
        System.out.println("2. Localizar produto pelo nome");
        System.out.println("3. Cadastrar produto");
        System.out.println("0. Salvar e sair");
        System.out.print("Escolha: ");
        try {
            return Integer.parseInt(teclado.nextLine().trim());
        } catch (NumberFormatException erro) {
            return -1;
        }
    }

    private static void pausa() {
        System.out.println("\nPressione Enter para continuar...");
        teclado.nextLine();
    }

    public static void main(String[] args) {
        if (args.length > 0) {
            nomeArquivoDados = args[0];
        }
        produtosCadastrados = lerProdutos(nomeArquivoDados);

        int opcao;
        do {
            opcao = menu();
            switch (opcao) {
                case 1: listarTodosOsProdutos(); break;
                case 2: localizarProdutos(); break;
                case 3: cadastrarProduto(); break;
                case 0: System.out.println("Encerrando e salvando os dados..."); break;
                default: System.out.println("Opção inválida.");
            }
            if (opcao != 0) pausa();
        } while (opcao != 0);

        salvarProdutos(nomeArquivoDados);
        teclado.close();
    }
}

