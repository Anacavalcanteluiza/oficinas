import java.util.Comparator;

/**
 * Selection Sort: procura o menor valor da parte ainda desordenada
 * e o coloca na próxima posição do início do vetor.
 */
public class SelectionSort<T> implements Ordenador<T> {
    private long comparacoes;
    private long movimentacoes;

    @Override
    public void ordenar(T[] vetor, Comparator<? super T> comparador) {
        if (vetor == null || comparador == null) {
            throw new IllegalArgumentException("Vetor e comparador não podem ser nulos.");
        }
        comparacoes = 0;
        movimentacoes = 0;

        for (int inicio = 0; inicio < vetor.length - 1; inicio++) {
            int indiceMenor = inicio;

            // Procura o índice do menor valor na parte que falta ordenar.
            for (int i = inicio + 1; i < vetor.length; i++) {
                comparacoes++;
                if (comparador.compare(vetor[i], vetor[indiceMenor]) < 0) {
                    indiceMenor = i;
                }
            }

            // Só troca se o menor valor não estiver já no lugar certo.
            if (indiceMenor != inicio) {
                T temporario = vetor[inicio];
                vetor[inicio] = vetor[indiceMenor];
                vetor[indiceMenor] = temporario;
                movimentacoes += 2;
            }
        }
    }

    @Override public long getComparacoes() { return comparacoes; }
    @Override public long getMovimentacoes() { return movimentacoes; }
    @Override public String getNome() { return "Selection Sort"; }
}
