import java.util.Comparator;

/**
 * Insertion Sort: pega um valor por vez e insere-o na posição correta
 * dentro da parte esquerda, que já está ordenada.
 */
public class InsertionSort<T> implements Ordenador<T> {
    private long comparacoes;
    private long movimentacoes;

    @Override
    public void ordenar(T[] vetor, Comparator<? super T> comparador) {
        if (vetor == null || comparador == null) {
            throw new IllegalArgumentException("Vetor e comparador não podem ser nulos.");
        }
        comparacoes = 0;
        movimentacoes = 0;

        for (int i = 1; i < vetor.length; i++) {
            T valorAtual = vetor[i];
            int posicao = i - 1;

            // Abre espaço movendo para a direita os valores maiores que valorAtual.
            while (posicao >= 0) {
                comparacoes++;
                if (comparador.compare(vetor[posicao], valorAtual) <= 0) {
                    break;
                }
                vetor[posicao + 1] = vetor[posicao];
                movimentacoes++;
                posicao--;
            }

            // Coloca o valor guardado no espaço que foi aberto.
            vetor[posicao + 1] = valorAtual;
            movimentacoes++;
        }
    }

    @Override public long getComparacoes() { return comparacoes; }
    @Override public long getMovimentacoes() { return movimentacoes; }
    @Override public String getNome() { return "Insertion Sort"; }
}
