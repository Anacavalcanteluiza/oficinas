import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;

/** Demonstração que compara os três algoritmos no mesmo conjunto de dados. */
public class App {
    // Tamanhos moderados: os algoritmos quadráticos ficam lentos para vetores enormes.
    private static final int[] TAMANHOS = {100, 500, 1_000, 5_000};
    private static final Random ALEATORIO = new Random(42);
    private static final Comparator<Integer> ORDEM_CRESCENTE = Integer::compareTo;

    public static void main(String[] args) {
        Ordenador<Integer>[] ordenadores = criarOrdenadores();

        System.out.printf("%-18s %10s %16s %16s %14s%n",
                "Algoritmo", "Tamanho", "Comparações", "Movimentações", "Tempo (ms)");

        for (int tamanho : TAMANHOS) {
            // Geramos uma vez e clonamos para que todos recebam os mesmos valores e ordem.
            Integer[] dadosOriginais = gerarDados(tamanho);

            for (Ordenador<Integer> ordenador : ordenadores) {
                Integer[] copia = dadosOriginais.clone();
                long inicio = System.nanoTime();
                ordenador.ordenar(copia, ORDEM_CRESCENTE);
                long tempoNanos = System.nanoTime() - inicio;

                // Confere o resultado para a comparação não mostrar números de um erro.
                if (!estaOrdenado(copia)) {
                    throw new IllegalStateException(ordenador.getNome() + " não ordenou corretamente.");
                }

                System.out.printf("%-18s %10d %16d %16d %14.3f%n",
                        ordenador.getNome(), tamanho,
                        ordenador.getComparacoes(), ordenador.getMovimentacoes(),
                        tempoNanos / 1_000_000.0);
            }
        }

        // Exemplo simples para mostrar que a interface também ordena textos.
        String[] nomes = {"Zoe", "Ana", "Bruno"};
        Ordenador<String> ordenadorDeTexto = new InsertionSort<>();
        ordenadorDeTexto.ordenar(nomes, String.CASE_INSENSITIVE_ORDER);
        System.out.println("\nExemplo com textos: " + Arrays.toString(nomes));
    }

    /** Cria os três ordenadores. A anotação suprime apenas um aviso do Java. */
    @SuppressWarnings("unchecked")
    private static Ordenador<Integer>[] criarOrdenadores() {
        return new Ordenador[] {
                new BubbleSort<Integer>(),
                new InsertionSort<Integer>(),
                new SelectionSort<Integer>()
        };
    }

    private static Integer[] gerarDados(int tamanho) {
        Integer[] dados = new Integer[tamanho];
        for (int i = 0; i < tamanho; i++) {
            dados[i] = ALEATORIO.nextInt(tamanho * 10 + 1);
        }
        return dados;
    }

    private static boolean estaOrdenado(Integer[] vetor) {
        for (int i = 1; i < vetor.length; i++) {
            if (vetor[i - 1] > vetor[i]) return false;
        }
        return true;
    }
}
