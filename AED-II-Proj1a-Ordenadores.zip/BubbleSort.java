import java.util.Comparator;

/**
 * Bubble Sort: compara vizinhos e troca-os quando estão fora de ordem.
 * A cada passagem, o maior valor ainda desordenado vai para o final.
 */
public class BubbleSort<T> implements Ordenador<T> {
    private long comparacoes;
    private long movimentacoes;

    @Override
    public void ordenar(T[] vetor, Comparator<? super T> comparador) {
        validar(vetor, comparador);
        comparacoes = 0;
        movimentacoes = 0;

        // A cada volta, a parte final do vetor já está ordenada.
        for (int fim = vetor.length - 1; fim > 0; fim--) {
            boolean houveTroca = false;
            for (int i = 0; i < fim; i++) {
                comparacoes++;
                if (comparador.compare(vetor[i], vetor[i + 1]) > 0) {
                    T temporario = vetor[i];
                    vetor[i] = vetor[i + 1];
                    vetor[i + 1] = temporario;
                    movimentacoes += 2; // Duas posições do vetor foram escritas.
                    houveTroca = true;
                }
            }
            // Se não houve troca, todos os valores já estão em ordem.
            if (!houveTroca) break;
        }
    }

    private void validar(T[] vetor, Comparator<? super T> comparador) {
        if (vetor == null || comparador == null) {
            throw new IllegalArgumentException("Vetor e comparador não podem ser nulos.");
        }
    }

    @Override public long getComparacoes() { return comparacoes; }
    @Override public long getMovimentacoes() { return movimentacoes; }
    @Override public String getNome() { return "Bubble Sort"; }
}
