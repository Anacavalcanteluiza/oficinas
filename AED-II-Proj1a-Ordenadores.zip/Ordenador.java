import java.util.Comparator;

/** Interface comum dos algoritmos de ordenação. */
public interface Ordenador<T> {
    /** Ordena o vetor recebido usando a regra de comparação informada. */
    void ordenar(T[] vetor, Comparator<? super T> comparador);

    /** Quantas vezes o algoritmo comparou dois valores. */
    long getComparacoes();

    /** Quantas escritas de valores foram feitas dentro do vetor. */
    long getMovimentacoes();

    /** Nome que será mostrado na tabela de resultados. */
    String getNome();
}
