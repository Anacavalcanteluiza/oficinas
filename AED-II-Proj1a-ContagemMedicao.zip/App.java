import java.util.Random;

/**
 * Compara a quantidade de operações principais e o tempo de quatro algoritmos.
 *
 * Critério de contagem usado neste programa:
 * 1. codigo1: uma operação por atualização da resposta;
 * 2. codigo2: uma operação por multiplicação;
 * 3. codigo3: uma operação por comparação entre elementos;
 * 4. codigo4: uma operação por soma feita depois de chamadas recursivas.
 *
 * O enunciado não define uma lista única de operações primitivas. Por isso,
 * contamos a operação que mais representa o trabalho de cada algoritmo.
 * O tempo é medido somente durante o algoritmo, sem incluir a criação do vetor.
 */
public class App {
    static final int[] tamanhosTesteGrande = {
            31_250_000, 62_500_000, 125_000_000, 250_000_000, 500_000_000
    };
    static final int[] tamanhosTesteMedio = {
            12_500, 25_000, 50_000, 100_000, 200_000
    };
    static final int[] tamanhosTestePequeno = {3, 6, 12, 24, 48};

    static Random aleatorio = new Random(42);
    static long operacoes;
    static final double nanoToMilli = 1.0 / 1_000_000;

    /** Soma os restos dos elementos que aparecem nos índices pares. */
    static int codigo1(int[] vetor) {
        int resposta = 0;
        for (int i = 0; i < vetor.length; i += 2) {
            resposta += vetor[i] % 2;
            operacoes++; // Conta uma atualização da resposta.
        }
        return resposta;
    }

    /** Executa uma quantidade de multiplicações que diminui pela metade. */
    static long codigo2(int[] vetor) {
        long contador = aleatorio.nextInt();
        for (int k = vetor.length - 1; k > 0; k /= 2) {
            for (int i = 0; i <= k; i++) {
                contador *= 2;
                operacoes++; // Conta uma multiplicação.
            }
        }
        return contador;
    }

    /** Ordena o vetor usando o método conhecido como seleção direta. */
    static void codigo3(int[] vetor) {
        for (int i = 0; i < vetor.length - 1; i++) {
            int menor = i;
            for (int j = i + 1; j < vetor.length; j++) {
                operacoes++; // Conta uma comparação entre dois valores.
                if (vetor[j] < vetor[menor]) {
                    menor = j;
                }
            }

            // Troca o elemento atual pelo menor que foi encontrado.
            int temp = vetor[i];
            vetor[i] = vetor[menor];
            vetor[menor] = temp;
        }
    }

    /** Calcula recursivamente uma sequência parecida com Fibonacci. */
    static int codigo4(int n) {
        if (n <= 2) {
            return 1; // Caso-base: encerra a recursão.
        }

        int resultadoEsquerdo = codigo4(n - 1);
        int resultadoDireito = codigo4(n - 2);
        operacoes++; // Conta a soma feita quando as duas respostas retornam.
        return resultadoEsquerdo + resultadoDireito;
    }

    /** Gera um vetor desordenado com valores inteiros positivos. */
    static int[] gerarVetor(int tamanho) {
        int[] vetor = new int[tamanho];
        int limiteExclusivo = Math.max(2, tamanho / 2);
        for (int i = 0; i < tamanho; i++) {
            vetor[i] = aleatorio.nextInt(1, limiteExclusivo);
        }
        return vetor;
    }

    /** Roda os algoritmos 1 ou 2 nos cinco tamanhos de teste grande. */
    private static void medirAlgoritmoDeVetor(int numeroAlgoritmo, int[] tamanhos) {
        System.out.println("\nAlgoritmo " + numeroAlgoritmo + " (vetores grandes)");
        System.out.printf("%-15s %-20s %-15s%n", "Tamanho", "Operações", "Tempo (ms)");

        for (int tamanho : tamanhos) {
            System.out.println("Preparando vetor com " + tamanho + " elementos...");
            int[] vetor = gerarVetor(tamanho);
            operacoes = 0;
            long inicio = System.nanoTime();

            if (numeroAlgoritmo == 1) {
                codigo1(vetor);
            } else {
                codigo2(vetor);
            }

            long duracao = System.nanoTime() - inicio;
            imprimirResultado(tamanho, operacoes, duracao);

            // Libera a referência para que a memória possa ser reaproveitada.
            vetor = null;
        }
    }

    /** Roda a ordenação, que tem muitos passos, nos tamanhos médios. */
    private static void medirAlgoritmo3(int[] tamanhos) {
        System.out.println("\nAlgoritmo 3 (vetores médios)");
        System.out.printf("%-15s %-20s %-15s%n", "Tamanho", "Operações", "Tempo (ms)");

        for (int tamanho : tamanhos) {
            int[] vetor = gerarVetor(tamanho);
            operacoes = 0;
            long inicio = System.nanoTime();
            codigo3(vetor);
            long duracao = System.nanoTime() - inicio;
            imprimirResultado(tamanho, operacoes, duracao);
        }
    }

    /** Mede o algoritmo recursivo para cada valor pequeno de n. */
    private static void medirAlgoritmo4(int[] valoresN) {
        System.out.println("\nAlgoritmo 4 (valores de n pequenos)");
        System.out.printf("%-15s %-20s %-15s%n", "n", "Operações", "Tempo (ms)");

        for (int n : valoresN) {
            operacoes = 0;
            long inicio = System.nanoTime();
            codigo4(n);
            long duracao = System.nanoTime() - inicio;
            imprimirResultado(n, operacoes, duracao);
        }
    }

    private static void imprimirResultado(int tamanho, long quantidade, long nanos) {
        System.out.printf("%-15d %-20d %-15.3f%n",
                tamanho, quantidade, nanos * nanoToMilli);
    }

    public static void main(String[] args) {
        System.out.println("Medição de operações principais e tempo de execução");
        System.out.println("Os vetores dos algoritmos 1 e 2 podem exigir até cerca de 2 GB de memória.");
        System.out.println("Execute com memória suficiente para o maior vetor ou reduza os tamanhos de teste.");

        medirAlgoritmoDeVetor(1, tamanhosTesteGrande);
        medirAlgoritmoDeVetor(2, tamanhosTesteGrande);
        medirAlgoritmo3(tamanhosTesteMedio);
        medirAlgoritmo4(tamanhosTestePequeno);
    }
}
